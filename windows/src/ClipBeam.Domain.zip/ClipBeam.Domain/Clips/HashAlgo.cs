﻿namespace ClipBeam.Domain.Clips
{
    public enum HashAlgo
    {
        Unspecified = 0,
        Sha256 = 1
    }
}
