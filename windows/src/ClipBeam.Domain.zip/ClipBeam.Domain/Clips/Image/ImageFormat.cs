﻿namespace ClipBeam.Domain.Clips.Image
{
    public enum ImageFormat 
    {
        Unspecified = 0,
        Png = 1,
        Webp = 2,
        Jpeg = 3
    }
}
