﻿namespace ClipBeam.Domain.Devices
{
    public enum Platform
    {
        Unspecified = 0,
        Windows = 1,
        Android = 2
    }
}