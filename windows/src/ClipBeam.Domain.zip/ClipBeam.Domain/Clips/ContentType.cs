﻿namespace ClipBeam.Domain.Clips
{
    public enum ContentType
    { 
        Unspecified = 0,
        Text = 1,
        Image = 2 
    }
}