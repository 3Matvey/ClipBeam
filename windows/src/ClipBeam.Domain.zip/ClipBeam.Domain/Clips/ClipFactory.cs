﻿using ClipBeam.Domain.Abstractions;
using ClipBeam.Domain.Clips.Image;
using ClipBeam.Domain.Clips.Text;
using ClipBeam.Domain.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClipBeam.Domain.Clips
{
    public static class ClipFactory
    {
        public const uint CurrentProtoVersion = 1;

        public static Clip CreateText(
            string originDeviceId,
            ulong seq,
            string? text,
            IHasherProvider hashers,
            HashAlgo algo = HashAlgo.Sha256,
            DateTime? createdUtcOverride = null)
        {
            ArgumentNullException.ThrowIfNull(hashers);

            var content = TextClipContent.FromRaw(text);

            // 2) хэш
            var hasher = hashers.Get(algo);
            var hash = hasher.Compute(content.Raw.Span);

            // 3) метаданные
            var createdUtc = createdUtcOverride ?? DateTime.UtcNow;
            if (createdUtc.Kind != DateTimeKind.Utc)
                createdUtc = DateTime.SpecifyKind(createdUtc, DateTimeKind.Utc);

            var meta = new ClipMeta(
                clipId: Guid.NewGuid(),
                originDeviceId: originDeviceId,
                seq: seq,
                type: ContentType.Text,
                contentHash: hash,
                totalSize: (ulong)content.Raw.Length,
                createdUtc: createdUtc,
                protoVersion: CurrentProtoVersion
            );

            // 4) агрегат
            return new Clip(meta, content);
        }

        /// <summary>
        /// Создать клип-изображение: ожидаются уже закодированные байты (PNG/WEBP/JPEG),
        /// метаданные изображения — в ImageMeta, хэш — по байтам контента.
        /// </summary>
        public static Clip CreateImage(
            string originDeviceId,
            ulong seq,
            ImageMeta imageMeta,
            ReadOnlyMemory<byte> encodedImageBytes,
            IHasherProvider hashers,
            HashAlgo algo = HashAlgo.Sha256,
            DateTime? createdUtcOverride = null)
        {
            if (hashers is null) throw new ArgumentNullException(nameof(hashers));
            if (imageMeta is null) throw new ArgumentNullException(nameof(imageMeta));
            if (encodedImageBytes.Length <= 0)
                throw new DomainException("Image bytes must be non-empty.");

            // 1) контент
            var content = new ImageClipContent(imageMeta, encodedImageBytes);

            // 2) хэш
            var hasher = hashers.Get(algo);
            var hash = hasher.Compute(content.Raw.Span);

            // 3) метаданные (базовые; imageMeta хранится в контенте)
            var createdUtc = createdUtcOverride ?? DateTime.UtcNow;
            if (createdUtc.Kind != DateTimeKind.Utc)
                createdUtc = DateTime.SpecifyKind(createdUtc, DateTimeKind.Utc);

            var meta = new ClipMeta(
                clipId: Guid.NewGuid(),
                originDeviceId: originDeviceId,
                seq: seq,
                type: ContentType.Image,
                contentHash: hash,
                totalSize: (ulong)content.Raw.Length,
                createdUtc: createdUtc,
                protoVersion: CurrentProtoVersion
            );

            return new Clip(meta, content);
        }
    }
}
