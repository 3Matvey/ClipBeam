﻿namespace ClipBeam.Domain.Devices
{
    public enum ChunkCompression 
    { 
        None = 0,
        Gzip = 1,
        Zstd = 2 
    }
}
