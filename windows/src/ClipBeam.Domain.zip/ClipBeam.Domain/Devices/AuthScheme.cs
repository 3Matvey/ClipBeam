﻿namespace ClipBeam.Domain.Devices
{
    public enum AuthScheme 
    { 
        Unspecified = 0,
        Tls = 1, 
        MTls = 2,
        Token = 3 
    }
}
